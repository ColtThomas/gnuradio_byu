#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright 2016 <+YOU OR YOUR COMPANY+>.
#
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
#

import numpy
from gnuradio import gr

class qpsk_modulate_custom(gr.basic_block):
    # Place your globals here
    samples_symbol = 1; # default samples per symbol
    """
    docstring for block qpsk_modulate_custom
    """
    def __init__(self, sample_per_symbol):
        gr.basic_block.__init__(self,
            name="qpsk_modulate_custom",
            in_sig=[numpy.complex64],
            out_sig=[numpy.complex64])
        self.samples_symbol=sample_per_symbol # bring in the parameter asap

    def forecast(self, noutput_items, ninput_items_required):
        #setup size of input_items[i] for work call
        for i in range(len(ninput_items_required)):
            ninput_items_required[i] = self.samples_symbol*noutput_items

    def general_work(self, input_items, output_items):
        output_items[0][:] = input_items[0]
        consume(0, len(input_items[0]))

        for i in range(0,(len(input_items)*self.sample_symbol))
            if(i%self.sample_symbol==0) #We are upsampling by inserting 0's inbetween samples
                output_items[i]=input_items[i]
            else
                output_items[i]=0

        return len(output_items[0])
