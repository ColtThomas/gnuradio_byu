#!/bin/sh
export VOLK_GENERIC=1
export GR_DONT_LOAD_PREFS=1
export srcdir=/usr/src/gnuradio/gnuradio/gr-filter/python/filter
export GR_CONF_CONTROLPORT_ON=False
export PATH=/usr/src/gnuradio/gnuradio/gr-kiwi/gr-filter/python/filter:$PATH
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH
export PYTHONPATH=/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/python:$PYTHONPATH
/usr/bin/python2 -B /usr/src/gnuradio/gnuradio/gr-filter/python/filter/qa_fft_filter.py 
