#!/bin/sh
export VOLK_GENERIC=1
export GR_DONT_LOAD_PREFS=1
export srcdir=/usr/src/gnuradio/gnuradio/gr-analog/lib
export GR_CONF_CONTROLPORT_ON=False
export PATH=/usr/src/gnuradio/gnuradio/gr-kiwi/gr-analog/lib:$PATH
export LD_LIBRARY_PATH=/usr/src/gnuradio/gnuradio/gr-kiwi/volk/lib:/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/lib:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-analog/lib:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-filter/lib:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-fft/lib:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-analog/lib:$LD_LIBRARY_PATH
export PYTHONPATH=/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/python:/usr/src/gnuradio/gnuradio/gnuradio-runtime/python:/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/swig:$PYTHONPATH
test-gr-analog 
