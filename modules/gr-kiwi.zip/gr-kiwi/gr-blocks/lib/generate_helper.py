#!/usr/bin/python2

import sys, os, re
sys.path.append('/usr/src/gnuradio/gnuradio/gnuradio-runtime/python')
os.environ['srcdir'] = '/usr/src/gnuradio/gnuradio/gr-blocks/lib'
os.chdir('/usr/src/gnuradio/gnuradio/gr-kiwi/gr-blocks/lib')

if __name__ == '__main__':
    import build_utils
    root, inp = sys.argv[1:3]
    for sig in sys.argv[3:]:
        name = re.sub ('X+', sig, root)
        d = build_utils.standard_dict(name, sig, 'blocks')
        build_utils.expand_template(d, inp, '_impl')
