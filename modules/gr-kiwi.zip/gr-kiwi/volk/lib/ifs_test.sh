#!/bin/sh
export IFS=:
echo "$*"
