#!/bin/sh
export VOLK_GENERIC=1
export GR_DONT_LOAD_PREFS=1
export srcdir=/usr/src/gnuradio/gnuradio/gr-uhd/python/uhd
export GR_CONF_CONTROLPORT_ON=False
export PATH=/usr/src/gnuradio/gnuradio/gr-kiwi/gr-uhd/python/uhd:$PATH
export LD_LIBRARY_PATH=/usr/src/gnuradio/gnuradio/gr-kiwi/volk/lib:/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/lib:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-uhd/lib:$LD_LIBRARY_PATH
export PYTHONPATH=/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/python:/usr/src/gnuradio/gnuradio/gnuradio-runtime/python:/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/swig:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-uhd/python:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-uhd/swig:$PYTHONPATH
/usr/bin/python2 -B /usr/src/gnuradio/gnuradio/gr-uhd/python/uhd/qa_uhd.py 
