#!/bin/sh
export VOLK_GENERIC=1
export GR_DONT_LOAD_PREFS=1
export srcdir=/usr/src/gnuradio/gnuradio/gr-fec/python/fec
export GR_CONF_CONTROLPORT_ON=False
export PATH=/usr/src/gnuradio/gnuradio/gr-kiwi/gr-fec/python/fec:$PATH
export LD_LIBRARY_PATH=/usr/src/gnuradio/gnuradio/gr-kiwi/volk/lib:/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/lib:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-fec/lib:$LD_LIBRARY_PATH
export PYTHONPATH=/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/python:/usr/src/gnuradio/gnuradio/gnuradio-runtime/python:/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/swig:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-fec/python:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-fec/swig:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-blocks/python:/usr/src/gnuradio/gnuradio/gr-kiwi/gr-blocks/swig:$PYTHONPATH
/usr/bin/python2 -B /usr/src/gnuradio/gnuradio/gr-fec/python/fec/qa_polar_encoder.py 
