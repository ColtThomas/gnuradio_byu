#!/bin/sh
export VOLK_GENERIC=1
export GR_DONT_LOAD_PREFS=1
export srcdir=/usr/src/gnuradio/gnuradio/gr-digital/python/digital
export GR_CONF_CONTROLPORT_ON=False
export PATH=/usr/src/gnuradio/gnuradio/gr-kiwi/gr-digital/python/digital:$PATH
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH
export PYTHONPATH=/usr/src/gnuradio/gnuradio/gr-kiwi/gnuradio-runtime/python:$PYTHONPATH
/usr/bin/python2 -B /usr/src/gnuradio/gnuradio/gr-digital/python/digital/qa_framer_sink.py 
